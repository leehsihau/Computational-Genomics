import sys
import random

# Tree class
class TreeNode:
    def __init__(self, id):
        self.id = id
        self.children = None

    #method for adding child, store children and their distances as a dictionary
    def add_child(self, node, distance):
        if not self.children:
            self.children = {}
        self.children[node] = distance

#Edge class Professor mentioned in class
class Edges:
    def __init__(self):
        self.edge_matrix=None
    #method for adding edge between two nodes, storing distance between them
    def add_edge(self, node1, node2, distance):
        if not self.edge_matrix:
            self.edge_matrix={}
        self.edge_matrix[node1]=(node2, distance)

    #get all edges
    def get_elements(self):
        return self.edge_matrix.items()

    #method for deleting an edge
    def delete_element(self, node):
        del self.edge_matrix[node.id]

#method for calculating two sequences' distances
def single_pair_difference(s1,s2):
    length = len(s1)
    mismatchCount = 0
    #iterate through two sequences
    for i in range(0,length):
        #check for their mismatches
        if s1[i] != s2[i]:
            mismatchCount += 1
    #calculating distance
    return float(mismatchCount) / float(length) 

#read fna file
def read_file(filename):
    #dictionary stores mapping from id to sequence
    dictionary = {}
    #all ids 
    id_list = []
    with open(filename) as f:
        content = f.read().splitlines()
    curr = None
    index=0
    for line in content:
        #even number line are ids
        if index % 2 == 0:
            #add the id to id_list
            curr = line[1:]
            id_list.append(curr)
        else:
            #mapping from id to the actual sequence
            dictionary[curr] = line
        index+=1
    return id_list, dictionary

#write distance file 
def write_distance_file(ids, matrix):
    count = len(ids)
    with open('genetic_distances.txt', 'w') as f:
        #the first row
        f.write('\t' + '\t'.join(ids) + '\n')
        #every line writes the corresponding id, the distance from other sequences and separated by tabs
        for i in range(0,count):
            f.write(ids[i] + '\t' + '\t'.join(map(str, matrix[i])) + '\n')

#Calculate the whole distance matrix
def fill_d_matrix(ids, id_to_seqs):
    length = len(ids)
    matrix = []
    #initialize the distance matrix with 0
    for i in range(0, length):
        placeholder=[]
        for j in range(0, length):
            placeholder.append(0)
        matrix.append(placeholder)
    i,j=0,0

    #for every pair of sequence, call single_pair_difference
    for id_1 in id_to_seqs:
        j=0
        for id_2 in id_to_seqs:
            matrix[i][j] = single_pair_difference(id_to_seqs[id_1], id_to_seqs[id_2])
            j+=1
        i+=1
    return matrix

#filling the empty Q-matrix for Neighbor-Joining based on distance matrix
def fill_q_matrix(q_matrix, d_matrix, length):
    #index of the pair of sequences that have the min value across Q-matrix
    index_1 = 0
    index_2 = 0
    #define the initial value of min infinity
    minVal = float('inf')
    for i in range(0,length):
        for j in range(0,length):
            #the same sequences
            if i == j:
                continue
            #filling this position using the formula from class
            q_matrix[i][j] = (length - 2) * d_matrix[i][j] - sum(d_matrix[i]) - sum(d_matrix[j])
            #updating minVal and the indices of minVal
            if q_matrix[i][j] < minVal:
                index_1 = i
                index_2 = j
                minVal = q_matrix[i][j]
    return q_matrix, index_1, index_2

#recalculating the distance between parent and the other remaining leaves
def update_d_matrix(d_matrix, new_d_matrix, index_1, index_2):
    length=len(d_matrix)
    #the old distance matrix's placeholder
    placeholder_d_matrix=[]
    #initialize all 0s
    for i in range(0, length+1):
        placeholder=[]
        for j in range(0, length+1):
            placeholder.append(0)
        placeholder_d_matrix.append(placeholder)
    #copy everything in the old distance matrix into the placeholder
    for i in range(0,length):
        for j in range(0,length):
            placeholder_d_matrix[i][j] = d_matrix[i][j]
    #recalculate the distance between the parent to all other nodes and store them into the placeholder, ends with the new added parent node
    for k in range(0,length):
        #formula of calculating distance between new parent node to k
        placeholder_d_matrix[length][k] = 1 / 2.0 * (d_matrix[index_1][k] + d_matrix[index_2][k] - d_matrix[index_1][index_2])
        #same as above
        placeholder_d_matrix[k][length] = placeholder_d_matrix[length][k]
    #indices for adding everything from the placeholder matrix except for the two removed indices: index_1 and index_2
    new_row_index = new_col_index = 0
    #process of removing index_1 and index_2 from placeholder and building the new distance matrix
    for i in range(0,length + 1):
        #do the same thing as j
        new_col_index = 0
        #do not add it to the new distance matrix if it's one of the removed two indices
        if i == index_1 or i == index_2:
            continue
        for j in range(0,length + 1):
            #same as above
            if j == index_1 or j == index_2:
                continue
            #add the current element in placeholder matrix to the new distance matrix
            new_d_matrix[new_row_index][new_col_index] = placeholder_d_matrix[i][j]
            #do the same thing as j
            new_col_index += 1
        #do the same thing as i
        new_row_index += 1
    #return the new distance matrix
    return new_d_matrix

#a global var that stores the mapping from id the the index (tips)
id_to_index = {}

#function for getting the id of index; separated by 2 cases: tips and internal nodes
def get_id_from_index(ids, index_):
    #using the global dictionary 
    global id_to_index
    #id of the node
    id_=0
    #first case, if the ids[index] is a tip, that means we can find it in our dictionary
    if ids[index_] in id_to_index:
        id_=id_to_index[ids[index_]]
    #if it's not a tip, that means we simply appended it to ids, so we can find it in the ids dictionary
    else:
        id_=ids[index_]

    return id_

#function of building edges object from the distance matrix
def build_edges_object(ids, d_matrix, edges):
    #the starting of internal node
    internal_node=120
    length  = len(ids)
    #iterate the core nei-saitou process (from wikipedia)
    while length>2:
        #initialize the Q matrix with all 0s
        q_matrix=[]
        for i in range(0, length):
            placeholder=[]
            for j in range(0, length):
                placeholder.append(0)
            q_matrix.append(placeholder)
        #call fill_1_matrix() function and get a filled matrix and two indices tha result in the minimum value
        q_matrix, index_1, index_2=fill_q_matrix(q_matrix.copy(), d_matrix, length)
        #calculating the distance between the new node to the two selected indices
        u_1 = 1 / 2.0 * d_matrix[index_1][index_2] + 1 / (2.0 * (length - 2)) * (sum(d_matrix[index_1]) - sum(d_matrix[index_2]))
        u_2 = d_matrix[index_1][index_2] - u_1

        #get the id of these two nodes
        id_1 = get_id_from_index(ids, index_1)
        id_2 = get_id_from_index(ids, index_2)

        #add these two edges into our edges object
        edges.add_edge(id_1, str(internal_node), u_1)
        edges.add_edge(id_2, str(internal_node), u_2)
        #a new list for storing ids
        newIds=[]
        #print("\n\n")
        #add everything into the newIds list except for the two that results in the minimum value
        for i in ids:
            if i is not ids[index_1] and i is not ids[index_2]:
                newIds.append(i)
        #add this internal node 
        newIds.append(str(internal_node))
        #make this newIds ids
        ids=newIds
        #internal_node for the next iteration
        internal_node -= 1
        #the new distance matrix
        new_d_matrix=[]
        #the new distance matrix is 1 size smaller because we are gonna remove the 2 min indices and add the new parent node
        for i in range(0, length-1):
            placeholder=[]
            for j in range(0, length-1):
                placeholder.append(0)
            new_d_matrix.append(placeholder)
        #call update_d_matrix() to get the new updated distance matrix
        d_matrix=update_d_matrix(d_matrix, new_d_matrix.copy(), index_1, index_2)
        #recalculate the length of ids since we just removed 2 and add 1
        length  = len(ids)
    #get the last two nodes in the distance matrix
    node_1=get_id_from_index(ids, 0)
    node_2=get_id_from_index(ids, 1)

    #add the edge between these two nodes
    edges.add_edge(node_1, node_2, d_matrix[0][1])
    #print("node1: "+str(node_1))
    #print("node2: "+str(node_2))
    #return node_2 as our root as defined in our handout (ntips+1)
    return node_2

def nei_saitou(ids, original_d_matrix):
    #initialize our edges object 
    edges=Edges()
    #using the global variable id_to_index dictionary
    global id_to_index
    #building our dictionary: "Tips must be indexed starting at 1, with 1 corresponding to the first sequence in the FASTA file"
    for i, id in enumerate(ids):
        id_to_index[id] = str(i + 1)

    #call the build edges object function, and get the returned root
    root = build_edges_object(ids, original_d_matrix , edges)
    #build the tree node from the root
    rootNode = TreeNode(root)
    #building the tree level by level starting from level 1
    tree_list = [rootNode]
    #level order tree building starts, exits when reaches the last level 
    while len(tree_list) > 0:
        #for storing the next level 
        placeholder = []
        #iterate through the list of parent nodes in this level
        for i in tree_list:
            for child, (parent, distance) in edges.get_elements():
                #if the parent node of this Edge object is i in our this level of tree, make i the child of the parent node
                if parent == i.id:
                    child = TreeNode(child)
                    i.add_child(child, distance)
                    #add it for checking the next level
                    placeholder.append(child)
        #delete the edges that have i as child
        for i in placeholder:
            edges.delete_element(i)
        #update tree_list for the next level building
        tree_list = placeholder
    return rootNode
#a global list storing the preorder traversal 
traversal=[]
def preorder(node):
    #exiting condition of preorder traversal
    if node==None or node.children==None:
        return
    #get the children, and their distances to the parent node of the parent node
    for child, distance in node.children.items():
        #using the global variable
        global traversal
        #recording the traversal 
        traversal.append((node.id, child.id, distance))
        preorder(child)
    return 
def write_edges_file(root):
    #doing preorder traversal
    preorder(root)
    #print(len(traversal))
    with open('edges.txt', 'w') as f:
        for (parent, child, distance) in traversal:
            #write the file with parent, child and distance separated by tab
            f.write(parent + '\t' + child + '\t' + str(distance) + '\n')

def postorder(node, ids):
    #check for leaf node 
    node_num=int(node.id)
    #leaf nodes range from 1 to 61
    if node_num>=1 and node_num<=61:
        #return its id
        return ids[node_num - 1]
    vals = []
    #iterate until the child nodes and then build the children part
    for child, distance in node.children.items():
        vals.append(postorder(child, ids) + ':' + str(distance))
    #wrap it up
    result = '(' + ','.join(vals) + ')'
    return result

def write_tree_file(ids, root):    
    #three children in the first level writes manually
    (first, fd), (second, sd), (third, td) = root.children.items()
    #postorder accordingly for the rest of them
    inner = postorder(first, ids)+ ':' + str(fd) + ',' + postorder(second, ids) + ':' + str(sd) + ','+ postorder(third, ids) + ':' + str(td)
    #wrap it up
    newick =  '(' + inner + ');'

    with open('tree.txt', 'w') as f:
        f.write(newick)



#a global variable to store the leaf node
leaves=set()
def get_leave_nodes(node):
    #check for leave nodes
    if not node or not node.children:
        #add it to the set
        leaves.add(node.id)
    else:
        #keep dfs
        for child in node.children.keys():
            get_leave_nodes(child)
    #because we are gonna remove it, keep the copy
    return leaves.copy()


def get_partitions(root):
    par_list = [root]
    #dictionary to store the partitions 
    partition = {}
    global leaves
    #performing level order traversal
    while len(par_list):
        #store nodes at next level
        placeholder = []
        #go through this level
        for node in par_list:
            #leaf nodes 
            if not node.children:
                continue
            #get the leave nodes of current node
            leaves_ = get_leave_nodes(node)
            #remove everything from the leaves set
            leaves.clear()
            #leaves of this node
            partition[node.id] = leaves_
            #store the children into the placeholder for next level 
            for child in node.children.keys():
                placeholder.append(child)
        #update for next level
        par_list = placeholder
    return partition

#list to store the dfs order of ids
order = []
def dfs_id(root):
    #return as reaching leaf node
    if not root or not root.children:
        return
    else:
        #keep doing dfs
        order.append(root.id)
        for child in root.children.keys():
            dfs_id(child)
    return order


def bootstrap(root, ids, id_to_seqs):
    #get all the ids in the dfs order
    ids_dfs_result = dfs_id(root)
    #get the original partitions as our benchmark
    original_partitions = get_partitions(root)
    #a list to store the frequencies
    par_num_list = []
    #total 59 internal nodes
    for i in range(0, 59):
        #initialize to 0
        par_num_list.append(0)
    #repeat 100 times
    for x in range(0,100):
        #new sequences 
        new_seqs = {}
        #all the choices we choose from
        all_choices = []
        #fill it with the indices 
        for i in range(0, len(id_to_seqs['152801'])):
            all_choices.append(i)
        #the choices we picked
        picked_=[]
        #randomly choose from the columns
        for i in range(0, len(all_choices)):
            picked_.append(random.choice(all_choices))
        #generating the new sequence, fill the whole 61 sequences
        for id_ in ids:
            new_seq = ''
            for index in picked_:
                new_seq += id_to_seqs[id_][index]
            new_seqs[id_] = new_seq
        #start doing distance_matrix and nei-saitou
        d_matrix = fill_d_matrix(ids, new_seqs)
        root = nei_saitou(ids, d_matrix)
        #get all the partitions in this tree
        partitions = get_partitions(root)

        #couting for the frequency
        for index, id_ in enumerate(ids_dfs_result):
            if original_partitions[id_] == partitions[id_]:
                par_num_list[index] += 1
    percentages=[]
    for i in par_num_list:
        percentages.append(i/100.0)
    return percentages

def write_bootstrap(percentages):
    with open('bootstrap.txt', 'w') as f:
        for percent in percentages:
            f.write(str(percent) + '\n')



def main(filename):
    ids, id_to_seqs = read_file(filename)
    #print(ids)
    #print("\n")
    #print(id_to_seqs)
    d_matrix = fill_d_matrix(ids, id_to_seqs)
    #print("\n")
    #print(d_matrix)
    write_distance_file(ids, d_matrix)
    root=nei_saitou(ids, d_matrix)
    #print(len(root.children))
    write_edges_file(root)
    write_tree_file(ids, root)
    percentages=bootstrap(root, ids, id_to_seqs)
    write_bootstrap(percentages)
filename=sys.argv[1]
main(filename)